from flask import Flask, render_template, request
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler

app = Flask(__name__)

# Load dataset
data = pd.read_csv("creditcard_2023.csv")

# Features and target
X = data.iloc[:, :-1]
y = data.iloc[:, -1]

# Feature scaling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

# Model training
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None

    if request.method == "POST":
        input_data = []
        for i in range(len(X.columns)):
            input_data.append(float(request.form[f"f{i}"]))

        input_scaled = scaler.transform([input_data])
        result = model.predict(input_scaled)

        if result[0] == 1:
            prediction = "🚨 Fraudulent Transaction"
        else:
            prediction = "✅ Legitimate Transaction"

    return render_template(
        "index.html",
        columns=X.columns,
        prediction=prediction
    )

if __name__ == "__main__":
    app.run(debug=True)
